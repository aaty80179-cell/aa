[bits 32]
global task_switch_asm

; void task_switch_asm(uint32_t* old_esp, uint32_t new_esp)
; Saves current context to old_esp stack, switches to new_esp stack
task_switch_asm:
    pusha                       ; Save all general registers
    pushf                       ; Save flags

    mov eax, [esp + 36]         ; Get old_esp pointer (after pusha + pushf)
    mov [eax], esp              ; Save current ESP to old task's stack pointer

    mov eax, [esp + 40]         ; Get new_esp
    mov esp, eax                ; Switch to new task's stack

    popf                        ; Restore flags
    popa                        ; Restore all general registers
    ret                         ; Return to new task's EIP
