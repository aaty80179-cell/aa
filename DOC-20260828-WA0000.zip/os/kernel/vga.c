#include "../include/vga.h"

/* ============================================================================
 * vga.c - VGA Text Mode Driver (80x25, 16 colors)
 * ============================================================================
 * Direct memory-mapped I/O at physical address 0xB8000.
 * Each cell: 2 bytes = [ASCII char, color attribute]
 * Color attribute: [background(4bits) | foreground(4bits)]
 * ============================================================================ */

static uint16_t* const vga_buffer = (uint16_t*)0xB8000;
static uint8_t vga_color_attr;
static uint16_t cursor_x = 0;
static uint16_t cursor_y = 0;

/* ----------------------------------------------------------------------------
 * Initialize VGA
 * ---------------------------------------------------------------------------- */
void vga_init(void) {
    vga_color_attr = vga_entry_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    cursor_x = 0;
    cursor_y = 0;
}

/* ----------------------------------------------------------------------------
 * Color helpers
 * ---------------------------------------------------------------------------- */
uint8_t vga_entry_color(enum vga_color fg, enum vga_color bg) {
    return fg | (bg << 4);
}

static uint16_t vga_entry(unsigned char c, uint8_t color) {
    return (uint16_t)c | ((uint16_t)color << 8);
}

/* ----------------------------------------------------------------------------
 * Update hardware cursor position (via VGA ports 0x3D4/0x3D5)
 * ---------------------------------------------------------------------------- */
static void vga_update_cursor(void) {
    uint16_t pos = cursor_y * VGA_WIDTH + cursor_x;

    outb(0x3D4, 0x0F);          /* Cursor location low register */
    outb(0x3D5, pos & 0xFF);
    outb(0x3D4, 0x0E);          /* Cursor location high register */
    outb(0x3D5, (pos >> 8) & 0xFF);
}

/* ----------------------------------------------------------------------------
 * Scroll screen up by one line
 * ---------------------------------------------------------------------------- */
static void vga_scroll(void) {
    if (cursor_y < VGA_HEIGHT) return;

    /* Move all lines up */
    for (int y = 0; y < VGA_HEIGHT - 1; y++) {
        for (int x = 0; x < VGA_WIDTH; x++) {
            vga_buffer[y * VGA_WIDTH + x] = vga_buffer[(y + 1) * VGA_WIDTH + x];
        }
    }

    /* Clear last line */
    for (int x = 0; x < VGA_WIDTH; x++) {
        vga_buffer[(VGA_HEIGHT - 1) * VGA_WIDTH + x] = vga_entry(' ', vga_color_attr);
    }

    cursor_y = VGA_HEIGHT - 1;
}

/* ----------------------------------------------------------------------------
 * Clear entire screen
 * ---------------------------------------------------------------------------- */
void vga_clear_screen(void) {
    for (int y = 0; y < VGA_HEIGHT; y++) {
        for (int x = 0; x < VGA_WIDTH; x++) {
            vga_buffer[y * VGA_WIDTH + x] = vga_entry(' ', vga_color_attr);
        }
    }
    cursor_x = 0;
    cursor_y = 0;
    vga_update_cursor();
}

/* ----------------------------------------------------------------------------
 * Move cursor to position
 * ---------------------------------------------------------------------------- */
void vga_gotoxy(uint16_t x, uint16_t y) {
    if (x >= VGA_WIDTH) x = VGA_WIDTH - 1;
    if (y >= VGA_HEIGHT) y = VGA_HEIGHT - 1;
    cursor_x = x;
    cursor_y = y;
    vga_update_cursor();
}

/* ----------------------------------------------------------------------------
 * Set foreground/background color
 * ---------------------------------------------------------------------------- */
void vga_set_color(enum vga_color fg, enum vga_color bg) {
    vga_color_attr = vga_entry_color(fg, bg);
}

/* ----------------------------------------------------------------------------
 * Print single character
 * ---------------------------------------------------------------------------- */
void vga_putchar(char c) {
    if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
    } else if (c == '\r') {
        cursor_x = 0;
    } else if (c == '\b') {
        if (cursor_x > 0) {
            cursor_x--;
            vga_buffer[cursor_y * VGA_WIDTH + cursor_x] = vga_entry(' ', vga_color_attr);
        }
    } else if (c == '\t') {
        cursor_x = (cursor_x + 8) & ~7;
        if (cursor_x >= VGA_WIDTH) {
            cursor_x = 0;
            cursor_y++;
        }
    } else {
        vga_buffer[cursor_y * VGA_WIDTH + cursor_x] = vga_entry(c, vga_color_attr);
        cursor_x++;
    }

    /* Handle line wrap */
    if (cursor_x >= VGA_WIDTH) {
        cursor_x = 0;
        cursor_y++;
    }

    /* Scroll if needed */
    if (cursor_y >= VGA_HEIGHT) {
        vga_scroll();
    }

    vga_update_cursor();
}

/* ----------------------------------------------------------------------------
 * Print null-terminated string
 * ---------------------------------------------------------------------------- */
void vga_puts(const char* str) {
    if (!str) return;
    for (int i = 0; str[i]; i++) {
        vga_putchar(str[i]);
    }
}

/* ----------------------------------------------------------------------------
 * Print 32-bit hex number
 * ---------------------------------------------------------------------------- */
void vga_puthex(uint32_t num) {
    const char* hex = "0123456789ABCDEF";
    vga_puts("0x");
    for (int i = 28; i >= 0; i -= 4) {
        vga_putchar(hex[(num >> i) & 0xF]);
    }
}

/* ----------------------------------------------------------------------------
 * Print 32-bit decimal number
 * ---------------------------------------------------------------------------- */
void vga_putdec(uint32_t num) {
    if (num == 0) {
        vga_putchar('0');
        return;
    }
    char buf[12];
    int i = 0;
    while (num > 0) {
        buf[i++] = '0' + (num % 10);
        num /= 10;
    }
    while (i > 0) {
        vga_putchar(buf[--i]);
    }
}

/* ----------------------------------------------------------------------------
 * Draw filled rectangle (for GUI)
 * ---------------------------------------------------------------------------- */
void vga_draw_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, char c) {
    for (uint16_t row = y; row < y + h && row < VGA_HEIGHT; row++) {
        for (uint16_t col = x; col < x + w && col < VGA_WIDTH; col++) {
            vga_buffer[row * VGA_WIDTH + col] = vga_entry(c, vga_color_attr);
        }
    }
}
