#include "../include/kernel.h"

/* ============================================================================
 * gdt.c - Global Descriptor Table
 * ============================================================================
 * Sets up flat 4GB segments for 32-bit protected mode.
 * Three entries: null, code (0x08), data (0x10).
 * ============================================================================ */

struct gdt_entry {
    uint16_t limit_low;     // Limit bits 0-15
    uint16_t base_low;      // Base bits 0-15
    uint8_t  base_middle;   // Base bits 16-23
    uint8_t  access;        // Access byte
    uint8_t  granularity;   // Granularity + limit bits 16-19
    uint8_t  base_high;     // Base bits 24-31
} __attribute__((packed));

struct gdt_ptr {
    uint16_t limit;         // Size of GDT - 1
    uint32_t base;          // Address of first GDT entry
} __attribute__((packed));

/* GDT with 3 entries: null, code, data */
static struct gdt_entry gdt[3];
static struct gdt_ptr gp;

extern void gdt_flush(uint32_t);

/* ----------------------------------------------------------------------------
 * Set a GDT gate
 * ---------------------------------------------------------------------------- */
static void gdt_set_gate(int num, uint32_t base, uint32_t limit, uint8_t access, uint8_t gran) {
    gdt[num].base_low    = (base & 0xFFFF);
    gdt[num].base_middle = (base >> 16) & 0xFF;
    gdt[num].base_high   = (base >> 24) & 0xFF;
    gdt[num].limit_low   = (limit & 0xFFFF);
    gdt[num].granularity = ((limit >> 16) & 0x0F);
    gdt[num].granularity |= (gran & 0xF0);
    gdt[num].access      = access;
}

/* ----------------------------------------------------------------------------
 * Initialize GDT
 * ---------------------------------------------------------------------------- */
void gdt_init(void) {
    gp.limit = (sizeof(struct gdt_entry) * 3) - 1;
    gp.base  = (uint32_t)&gdt;

    /* Null descriptor */
    gdt_set_gate(0, 0, 0, 0, 0);

    /* Code segment: base 0, limit 4GB, ring 0, executable, readable */
    gdt_set_gate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF);

    /* Data segment: base 0, limit 4GB, ring 0, writable */
    gdt_set_gate(2, 0, 0xFFFFFFFF, 0x92, 0xCF);

    gdt_flush((uint32_t)&gp);
}
