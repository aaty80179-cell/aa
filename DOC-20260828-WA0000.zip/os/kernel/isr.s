[bits 32]

; Export all ISR and IRQ handlers
global isr0
global isr1
global isr2
global isr3
global isr4
global isr5
global isr6
global isr7
global isr8
global isr9
global isr10
global isr11
global isr12
global isr13
global isr14
global isr15
global isr16
global isr17
global isr18
global isr19
global isr20
global isr21
global isr22
global isr23
global isr24
global isr25
global isr26
global isr27
global isr28
global isr29
global isr30
global isr31

global irq0
global irq1
global irq2
global irq3
global irq4
global irq5
global irq6
global irq7
global irq8
global irq9
global irq10
global irq11
global irq12
global irq13
global irq14
global irq15

global idt_load

; ----------------------------------------------------------------------------
; IDT Load
; ----------------------------------------------------------------------------
idt_load:
    mov eax, [esp + 4]
    lidt [eax]
    ret

; ----------------------------------------------------------------------------
; ISR Macros
; ISR_NOERR: CPU pushes no error code, we push dummy 0
; ISR_ERR: CPU pushes error code automatically
; ----------------------------------------------------------------------------

; ISR 0-7 (no error code)
isr0:   cli
        push dword 0
        push dword 0
        jmp isr_common_stub

isr1:   cli
        push dword 0
        push dword 1
        jmp isr_common_stub

isr2:   cli
        push dword 0
        push dword 2
        jmp isr_common_stub

isr3:   cli
        push dword 0
        push dword 3
        jmp isr_common_stub

isr4:   cli
        push dword 0
        push dword 4
        jmp isr_common_stub

isr5:   cli
        push dword 0
        push dword 5
        jmp isr_common_stub

isr6:   cli
        push dword 0
        push dword 6
        jmp isr_common_stub

isr7:   cli
        push dword 0
        push dword 7
        jmp isr_common_stub

; ISR 8-14 (with error code, except 9)
isr8:   cli
        push dword 8
        jmp isr_common_stub

isr9:   cli
        push dword 0
        push dword 9
        jmp isr_common_stub

isr10:  cli
        push dword 10
        jmp isr_common_stub

isr11:  cli
        push dword 11
        jmp isr_common_stub

isr12:  cli
        push dword 12
        jmp isr_common_stub

isr13:  cli
        push dword 13
        jmp isr_common_stub

isr14:  cli
        push dword 14
        jmp isr_common_stub

; ISR 15-31 (no error code)
isr15:  cli
        push dword 0
        push dword 15
        jmp isr_common_stub

isr16:  cli
        push dword 0
        push dword 16
        jmp isr_common_stub

isr17:  cli
        push dword 17
        jmp isr_common_stub

isr18:  cli
        push dword 0
        push dword 18
        jmp isr_common_stub

isr19:  cli
        push dword 0
        push dword 19
        jmp isr_common_stub

isr20:  cli
        push dword 0
        push dword 20
        jmp isr_common_stub

isr21:  cli
        push dword 0
        push dword 21
        jmp isr_common_stub

isr22:  cli
        push dword 0
        push dword 22
        jmp isr_common_stub

isr23:  cli
        push dword 0
        push dword 23
        jmp isr_common_stub

isr24:  cli
        push dword 0
        push dword 24
        jmp isr_common_stub

isr25:  cli
        push dword 0
        push dword 25
        jmp isr_common_stub

isr26:  cli
        push dword 0
        push dword 26
        jmp isr_common_stub

isr27:  cli
        push dword 0
        push dword 27
        jmp isr_common_stub

isr28:  cli
        push dword 0
        push dword 28
        jmp isr_common_stub

isr29:  cli
        push dword 0
        push dword 29
        jmp isr_common_stub

isr30:  cli
        push dword 30
        jmp isr_common_stub

isr31:  cli
        push dword 0
        push dword 31
        jmp isr_common_stub

; ----------------------------------------------------------------------------
; IRQ Handlers (mapped to ISR 32-47 after PIC remapping)
; All IRQs push dummy error code 0, then vector number
; ----------------------------------------------------------------------------
irq0:   cli
        push dword 0
        push dword 32
        jmp irq_common_stub

irq1:   cli
        push dword 0
        push dword 33
        jmp irq_common_stub

irq2:   cli
        push dword 0
        push dword 34
        jmp irq_common_stub

irq3:   cli
        push dword 0
        push dword 35
        jmp irq_common_stub

irq4:   cli
        push dword 0
        push dword 36
        jmp irq_common_stub

irq5:   cli
        push dword 0
        push dword 37
        jmp irq_common_stub

irq6:   cli
        push dword 0
        push dword 38
        jmp irq_common_stub

irq7:   cli
        push dword 0
        push dword 39
        jmp irq_common_stub

irq8:   cli
        push dword 0
        push dword 40
        jmp irq_common_stub

irq9:   cli
        push dword 0
        push dword 41
        jmp irq_common_stub

irq10:  cli
        push dword 0
        push dword 42
        jmp irq_common_stub

irq11:  cli
        push dword 0
        push dword 43
        jmp irq_common_stub

irq12:  cli
        push dword 0
        push dword 44
        jmp irq_common_stub

irq13:  cli
        push dword 0
        push dword 45
        jmp irq_common_stub

irq14:  cli
        push dword 0
        push dword 46
        jmp irq_common_stub

irq15:  cli
        push dword 0
        push dword 47
        jmp irq_common_stub

; ----------------------------------------------------------------------------
; Common ISR Stub - CPU Exception Handler
; Stack layout after pushes: [esp+0]=err_code, [esp+4]=int_no
; Then we push all registers and segment registers
; ----------------------------------------------------------------------------
extern isr_handler

isr_common_stub:
    pusha
    push ds
    push es
    push fs
    push gs

    mov ax, 0x10                        ; Kernel data segment
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax

    mov eax, esp
    push eax                            ; Pass stack pointer as argument
    call isr_handler
    pop eax

    pop gs
    pop fs
    pop es
    pop ds
    popa
    add esp, 8                          ; Remove err_code and int_no
    sti
    iret

; ----------------------------------------------------------------------------
; Common IRQ Stub - Hardware Interrupt Handler
; Same structure as ISR stub but calls irq_handler instead
; ----------------------------------------------------------------------------
extern irq_handler

irq_common_stub:
    pusha
    push ds
    push es
    push fs
    push gs

    mov ax, 0x10                        ; Kernel data segment
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax

    mov eax, esp
    push eax                            ; Pass stack pointer as argument
    call irq_handler
    pop eax

    pop gs
    pop fs
    pop es
    pop ds
    popa
    add esp, 8                          ; Remove dummy err_code and int_no
    sti
    iret
