#include "../include/kernel.h"
#include "../include/paging.h"

/* ============================================================================
 * paging.c - Memory Management Unit (MMU) with Paging
 * ============================================================================
 * 32-bit paging with 4KB pages.
 * Identity maps first 4MB (kernel code + data + heap).
 * Page directory at 0x100000, page tables follow.
 * ============================================================================ */

/* Page directory and first page table (must be 4KB aligned) */
static uint32_t page_directory[1024] __attribute__((aligned(4096)));
static uint32_t first_page_table[1024] __attribute__((aligned(4096)));

/* Heap management */
static uint32_t heap_start = 0x00400000;    /* 4MB - start of heap */
static uint32_t heap_end   = 0x00800000;    /* 8MB - end of heap */
static uint32_t heap_ptr   = 0x00400000;    /* Current heap pointer */

/* ----------------------------------------------------------------------------
 * Initialize paging: identity map first 4MB
 * ---------------------------------------------------------------------------- */
void paging_init(void) {
    /* Clear page directory */
    for (int i = 0; i < 1024; i++) {
        page_directory[i] = 0x00000002;     /* Supervisor, RW, Not Present */
    }

    /* Identity map first 4MB (1024 pages * 4KB) */
    for (int i = 0; i < 1024; i++) {
        first_page_table[i] = (i * 0x1000) | 0x03;  /* Present, RW, Supervisor */
    }

    /* Set page directory entry 0 to point to first_page_table */
    page_directory[0] = ((uint32_t)first_page_table) | 0x03;

    /* Load page directory into CR3 */
    asm volatile("mov %0, %%cr3" :: "r"(page_directory));

    /* Enable paging (PG bit in CR0) */
    uint32_t cr0;
    asm volatile("mov %%cr0, %0" : "=r"(cr0));
    cr0 |= 0x80000000;
    asm volatile("mov %0, %%cr0" :: "r"(cr0));
}

/* ----------------------------------------------------------------------------
 * Simple bump allocator (page-aligned)
 * Returns NULL if out of memory
 * ---------------------------------------------------------------------------- */
void* kmalloc(uint32_t size) {
    if (size == 0) return NULL;

    /* Align to 4KB boundary */
    uint32_t aligned_size = (size + 0xFFF) & ~0xFFF;

    if (heap_ptr + aligned_size > heap_end) {
        return NULL;  /* Out of memory */
    }

    void* ptr = (void*)heap_ptr;
    heap_ptr += aligned_size;
    return ptr;
}

/* ----------------------------------------------------------------------------
 * Free memory (no-op for bump allocator)
 * In a real OS, this would return pages to a free list
 * ---------------------------------------------------------------------------- */
void kfree(void* ptr) {
    (void)ptr;
    /* TODO: Implement proper free list for kmalloc */
}

/* ----------------------------------------------------------------------------
 * Get heap usage statistics
 * ---------------------------------------------------------------------------- */
uint32_t paging_get_used(void) {
    return heap_ptr - heap_start;
}

uint32_t paging_get_total(void) {
    return heap_end - heap_start;
}
