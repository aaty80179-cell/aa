#include "../../include/gui.h"

/* ============================================================================
 * taskbar.c - Taskbar with Start button, apps, and system tray
 * ============================================================================ */

void taskbar_init(void) {
    if (vesa_is_active()) {
        vesa_draw_taskbar();
        return;
    }

    /* VGA text mode taskbar */
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_DARK_GREY);
    vga_draw_rect(0, VGA_HEIGHT - 1, VGA_WIDTH, 1, ' ');

    /* Start button */
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLUE);
    vga_gotoxy(1, VGA_HEIGHT - 1);
    vga_puts(" Start ");

    /* Running apps */
    vga_set_color(VGA_COLOR_BLACK, VGA_COLOR_LIGHT_GREY);
    vga_gotoxy(10, VGA_HEIGHT - 1);
    vga_puts("File Explorer");
    vga_gotoxy(26, VGA_HEIGHT - 1);
    vga_puts("Browser");
    vga_gotoxy(35, VGA_HEIGHT - 1);
    vga_puts("Terminal");

    /* System tray / Clock */
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_DARK_GREY);
    vga_gotoxy(65, VGA_HEIGHT - 1);
    vga_puts("12:00 PM");
}
