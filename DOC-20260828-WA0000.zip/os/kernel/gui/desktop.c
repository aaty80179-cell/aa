#include "../../include/gui.h"

/* ============================================================================
 * desktop.c - Desktop Environment
 * ============================================================================ */

void desktop_init(void) {
    if (vesa_is_active()) {
        vesa_draw_desktop();
        return;
    }

    /* VGA text mode desktop */
    vga_set_color(VGA_COLOR_LIGHT_CYAN, VGA_COLOR_BLUE);
    vga_draw_rect(0, 0, VGA_WIDTH, VGA_HEIGHT - 1, ' ');

    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLUE);

    /* Desktop icons */
    vga_gotoxy(2, 1);
    vga_puts("[PC] My Computer");
    vga_gotoxy(2, 3);
    vga_puts("[RB] Recycle Bin");
    vga_gotoxy(2, 5);
    vga_puts("[DO] Documents");
    vga_gotoxy(2, 7);
    vga_puts("[SE] Settings");
    vga_gotoxy(2, 9);
    vga_puts("[NE] Network");
}
