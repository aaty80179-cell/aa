#include "../../include/gui.h"

/* ============================================================================
 * window.c - Window Manager
 * ============================================================================ */

void window_init(void) {
    if (vesa_is_active()) {
        vesa_draw_window(140, 40, 380, 260, "File Explorer");
        return;
    }

    /* VGA text mode window */
    int wx = 15, wy = 5, ww = 40, wh = 12;

    /* Title bar */
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLUE);
    vga_draw_rect(wx, wy, ww, 1, ' ');
    vga_gotoxy(wx + 2, wy);
    vga_puts("File Explorer - This PC");

    /* Window buttons */
    vga_gotoxy(wx + ww - 3, wy);
    vga_putchar('X');
    vga_gotoxy(wx + ww - 5, wy);
    vga_putchar('+');
    vga_gotoxy(wx + ww - 7, wy);
    vga_putchar('-');

    /* Window body */
    vga_set_color(VGA_COLOR_BLACK, VGA_COLOR_LIGHT_GREY);
    vga_draw_rect(wx, wy + 1, ww, wh - 1, ' ');

    /* Content */
    vga_set_color(VGA_COLOR_BLACK, VGA_COLOR_WHITE);
    vga_gotoxy(wx + 2, wy + 3);
    vga_puts("> Local Disk (C:)");
    vga_gotoxy(wx + 2, wy + 5);
    vga_puts("> Local Disk (D:)");
    vga_gotoxy(wx + 2, wy + 7);
    vga_puts("> Network");
    vga_gotoxy(wx + 2, wy + 9);
    vga_puts("> Control Panel");
}
