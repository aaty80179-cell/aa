#include "../include/kernel.h"
#include "../include/multitasking.h"

/* ============================================================================
 * multitasking.c - Cooperative Multitasking (Linux-style, TSS-less)
 * ============================================================================
 * Software context switching by manually saving/restoring registers.
 * No hardware TSS used (Linux approach - faster and portable).
 * ============================================================================ */

#define MAX_TASKS       16
#define STACK_SIZE      8192    /* 8KB stack per task */
#define TASK_NAME_LEN   32

typedef enum {
    TASK_READY,
    TASK_RUNNING,
    TASK_BLOCKED,
    TASK_ZOMBIE
} task_state_t;

typedef struct task {
    uint32_t esp;               /* Stack pointer */
    uint32_t ebp;               /* Base pointer */
    uint32_t eip;               /* Instruction pointer */
    uint32_t eax, ebx, ecx, edx;
    uint32_t esi, edi;
    uint32_t eflags;
    uint8_t  stack[STACK_SIZE]; /* Task stack */
    task_state_t state;
    uint8_t  priority;
    char     name[TASK_NAME_LEN];
    uint32_t pid;               /* Process ID */
} task_t;

static task_t tasks[MAX_TASKS];
static int current_task = -1;
static int num_tasks = 0;
static uint32_t next_pid = 1;

extern void task_switch_asm(uint32_t* old_esp, uint32_t new_esp);

/* ----------------------------------------------------------------------------
 * Initialize task subsystem
 * ---------------------------------------------------------------------------- */
void task_init(void) {
    for (int i = 0; i < MAX_TASKS; i++) {
        tasks[i].state = TASK_ZOMBIE;
        tasks[i].pid = 0;
    }
    current_task = -1;
    num_tasks = 0;
    next_pid = 1;
}

/* ----------------------------------------------------------------------------
 * Create new task
 * Returns: task PID on success, -1 on failure
 * ---------------------------------------------------------------------------- */
int task_create(void (*entry_point)(void), const char* name, uint8_t priority) {
    if (num_tasks >= MAX_TASKS) return -1;
    if (!entry_point) return -1;

    /* Find free slot */
    int slot = -1;
    for (int i = 0; i < MAX_TASKS; i++) {
        if (tasks[i].state == TASK_ZOMBIE) {
            slot = i;
            break;
        }
    }
    if (slot == -1) return -1;

    task_t* task = &tasks[slot];

    /* Copy name */
    int j = 0;
    while (name[j] && j < TASK_NAME_LEN - 1) {
        task->name[j] = name[j];
        j++;
    }
    task->name[j] = '\0';

    task->pid = next_pid++;
    task->priority = priority;
    task->state = TASK_READY;

    /* Setup initial stack */
    uint32_t* stack = (uint32_t*)(task->stack + STACK_SIZE);

    /* Push initial register values (for iret simulation) */
    *(--stack) = 0x202;                     /* EFLAGS (IF set) */
    *(--stack) = 0x08;                      /* CS (kernel code) */
    *(--stack) = (uint32_t)entry_point;      /* EIP */

    /* Push general registers (will be popped by popa in task_switch_asm) */
    *(--stack) = 0;     /* EDI */
    *(--stack) = 0;     /* ESI */
    *(--stack) = 0;     /* EBP */
    *(--stack) = 0;     /* ESP (placeholder) */
    *(--stack) = 0;     /* EBX */
    *(--stack) = 0;     /* EDX */
    *(--stack) = 0;     /* ECX */
    *(--stack) = 0;     /* EAX */

    task->esp = (uint32_t)stack;
    task->ebp = 0;
    task->eip = (uint32_t)entry_point;

    num_tasks++;

    if (current_task == -1) {
        current_task = slot;
        task->state = TASK_RUNNING;
    }

    return task->pid;
}

/* ----------------------------------------------------------------------------
 * Yield CPU to next ready task (round-robin)
 * ---------------------------------------------------------------------------- */
void task_yield(void) {
    if (num_tasks <= 1) return;

    int old_task = current_task;
    int next_task = old_task;

    /* Find next ready task */
    do {
        next_task = (next_task + 1) % MAX_TASKS;
    } while (tasks[next_task].state != TASK_READY && next_task != old_task);

    if (next_task == old_task) return;

    /* Save old task state */
    tasks[old_task].state = TASK_READY;

    /* Switch to new task */
    current_task = next_task;
    tasks[next_task].state = TASK_RUNNING;

    task_switch_asm(&tasks[old_task].esp, tasks[next_task].esp);
}

/* ----------------------------------------------------------------------------
 * Exit current task
 * ---------------------------------------------------------------------------- */
void task_exit(void) {
    if (current_task < 0 || current_task >= MAX_TASKS) return;

    tasks[current_task].state = TASK_ZOMBIE;
    tasks[current_task].pid = 0;
    num_tasks--;

    if (num_tasks == 0) {
        while (1) asm volatile("cli; hlt");
    }

    /* Find next ready task */
    int next_task = -1;
    for (int i = 0; i < MAX_TASKS; i++) {
        if (tasks[i].state == TASK_READY) {
            next_task = i;
            break;
        }
    }

    if (next_task != -1) {
        current_task = next_task;
        tasks[next_task].state = TASK_RUNNING;
        asm volatile("mov %0, %%esp" :: "r"(tasks[next_task].esp));
        asm volatile("popa");
        asm volatile("iret");
    }

    while (1) asm volatile("cli; hlt");
}

/* ----------------------------------------------------------------------------
 * Get current task PID
 * ---------------------------------------------------------------------------- */
int task_get_current(void) {
    if (current_task < 0 || current_task >= MAX_TASKS) return -1;
    return tasks[current_task].pid;
}

/* ----------------------------------------------------------------------------
 * Get task name by PID
 * ---------------------------------------------------------------------------- */
const char* task_get_name(int pid) {
    for (int i = 0; i < MAX_TASKS; i++) {
        if (tasks[i].pid == pid) {
            return tasks[i].name;
        }
    }
    return "unknown";
}

/* ----------------------------------------------------------------------------
 * Get number of active tasks
 * ---------------------------------------------------------------------------- */
int task_get_count(void) {
    return num_tasks;
}
