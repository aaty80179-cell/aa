#include "../include/kernel.h"
#include "../include/pic.h"

/* ============================================================================
 * idt.c - Interrupt Descriptor Table
 * ============================================================================
 * 256 entries covering:
 *   0-31:   CPU exceptions (reserved by Intel)
 *   32-47:  Hardware IRQs (remapped from PIC: IRQ 0-15 -> ISR 32-47)
 *   48-255: Available for software interrupts
 * ============================================================================ */

struct idt_entry {
    uint16_t base_lo;       // Handler address bits 0-15
    uint16_t sel;           // Kernel code segment selector
    uint8_t  always0;       // Always zero
    uint8_t  flags;         // Type and attributes (0x8E = present, ring 0, 32-bit interrupt gate)
    uint16_t base_hi;       // Handler address bits 16-31
} __attribute__((packed));

struct idt_ptr {
    uint16_t limit;         // Size of IDT - 1
    uint32_t base;          // Address of first IDT entry
} __attribute__((packed));

static struct idt_entry idt[256];
static struct idt_ptr idtp;

/* External ISR/IRQ stubs from isr.s */
extern void idt_load(uint32_t);
extern void isr0(void),  isr1(void),  isr2(void),  isr3(void),  isr4(void),  isr5(void),  isr6(void),  isr7(void);
extern void isr8(void),  isr9(void),  isr10(void), isr11(void), isr12(void), isr13(void), isr14(void), isr15(void);
extern void isr16(void), isr17(void), isr18(void), isr19(void), isr20(void), isr21(void), isr22(void), isr23(void);
extern void isr24(void), isr25(void), isr26(void), isr27(void), isr28(void), isr29(void), isr30(void), isr31(void);
extern void irq0(void),  irq1(void),  irq2(void),  irq3(void),  irq4(void),  irq5(void),  irq6(void),  irq7(void);
extern void irq8(void),  irq9(void),  irq10(void), irq11(void), irq12(void), irq13(void), irq14(void), irq15(void);

/* CPU exception messages */
static const char* const exception_messages[] = {
    "Division by zero",
    "Debug",
    "Non-maskable interrupt",
    "Breakpoint",
    "Into detected overflow",
    "Out of bounds",
    "Invalid opcode",
    "No coprocessor",
    "Double fault",
    "Coprocessor segment overrun",
    "Bad TSS",
    "Segment not present",
    "Stack fault",
    "General protection fault",
    "Page fault",
    "Unknown interrupt",
    "Coprocessor fault",
    "Alignment check",
    "Machine check",
    "Reserved",
    "Reserved", "Reserved", "Reserved", "Reserved",
    "Reserved", "Reserved", "Reserved", "Reserved",
    "Reserved", "Reserved", "Reserved", "Reserved"
};

/* ----------------------------------------------------------------------------
 * Set an IDT gate
 * ---------------------------------------------------------------------------- */
static void idt_set_gate(uint8_t num, uint32_t base, uint16_t sel, uint8_t flags) {
    idt[num].base_lo  = base & 0xFFFF;
    idt[num].base_hi  = (base >> 16) & 0xFFFF;
    idt[num].sel      = sel;
    idt[num].always0  = 0;
    idt[num].flags    = flags;
}

/* ----------------------------------------------------------------------------
 * Initialize IDT with all 256 entries
 * ---------------------------------------------------------------------------- */
void idt_init(void) {
    idtp.limit = (sizeof(struct idt_entry) * 256) - 1;
    idtp.base  = (uint32_t)&idt;

    /* Clear all entries */
    for (int i = 0; i < 256; i++) {
        idt_set_gate(i, 0, 0, 0);
    }

    /* CPU Exceptions (ISR 0-31) */
    idt_set_gate(0,  (uint32_t)isr0,  0x08, 0x8E);
    idt_set_gate(1,  (uint32_t)isr1,  0x08, 0x8E);
    idt_set_gate(2,  (uint32_t)isr2,  0x08, 0x8E);
    idt_set_gate(3,  (uint32_t)isr3,  0x08, 0x8E);
    idt_set_gate(4,  (uint32_t)isr4,  0x08, 0x8E);
    idt_set_gate(5,  (uint32_t)isr5,  0x08, 0x8E);
    idt_set_gate(6,  (uint32_t)isr6,  0x08, 0x8E);
    idt_set_gate(7,  (uint32_t)isr7,  0x08, 0x8E);
    idt_set_gate(8,  (uint32_t)isr8,  0x08, 0x8E);
    idt_set_gate(9,  (uint32_t)isr9,  0x08, 0x8E);
    idt_set_gate(10, (uint32_t)isr10, 0x08, 0x8E);
    idt_set_gate(11, (uint32_t)isr11, 0x08, 0x8E);
    idt_set_gate(12, (uint32_t)isr12, 0x08, 0x8E);
    idt_set_gate(13, (uint32_t)isr13, 0x08, 0x8E);
    idt_set_gate(14, (uint32_t)isr14, 0x08, 0x8E);
    idt_set_gate(15, (uint32_t)isr15, 0x08, 0x8E);
    idt_set_gate(16, (uint32_t)isr16, 0x08, 0x8E);
    idt_set_gate(17, (uint32_t)isr17, 0x08, 0x8E);
    idt_set_gate(18, (uint32_t)isr18, 0x08, 0x8E);
    idt_set_gate(19, (uint32_t)isr19, 0x08, 0x8E);
    idt_set_gate(20, (uint32_t)isr20, 0x08, 0x8E);
    idt_set_gate(21, (uint32_t)isr21, 0x08, 0x8E);
    idt_set_gate(22, (uint32_t)isr22, 0x08, 0x8E);
    idt_set_gate(23, (uint32_t)isr23, 0x08, 0x8E);
    idt_set_gate(24, (uint32_t)isr24, 0x08, 0x8E);
    idt_set_gate(25, (uint32_t)isr25, 0x08, 0x8E);
    idt_set_gate(26, (uint32_t)isr26, 0x08, 0x8E);
    idt_set_gate(27, (uint32_t)isr27, 0x08, 0x8E);
    idt_set_gate(28, (uint32_t)isr28, 0x08, 0x8E);
    idt_set_gate(29, (uint32_t)isr29, 0x08, 0x8E);
    idt_set_gate(30, (uint32_t)isr30, 0x08, 0x8E);
    idt_set_gate(31, (uint32_t)isr31, 0x08, 0x8E);

    /* Hardware IRQs (ISR 32-47) */
    idt_set_gate(32, (uint32_t)irq0,  0x08, 0x8E);
    idt_set_gate(33, (uint32_t)irq1,  0x08, 0x8E);
    idt_set_gate(34, (uint32_t)irq2,  0x08, 0x8E);
    idt_set_gate(35, (uint32_t)irq3,  0x08, 0x8E);
    idt_set_gate(36, (uint32_t)irq4,  0x08, 0x8E);
    idt_set_gate(37, (uint32_t)irq5,  0x08, 0x8E);
    idt_set_gate(38, (uint32_t)irq6,  0x08, 0x8E);
    idt_set_gate(39, (uint32_t)irq7,  0x08, 0x8E);
    idt_set_gate(40, (uint32_t)irq8,  0x08, 0x8E);
    idt_set_gate(41, (uint32_t)irq9,  0x08, 0x8E);
    idt_set_gate(42, (uint32_t)irq10, 0x08, 0x8E);
    idt_set_gate(43, (uint32_t)irq11, 0x08, 0x8E);
    idt_set_gate(44, (uint32_t)irq12, 0x08, 0x8E);
    idt_set_gate(45, (uint32_t)irq13, 0x08, 0x8E);
    idt_set_gate(46, (uint32_t)irq14, 0x08, 0x8E);
    idt_set_gate(47, (uint32_t)irq15, 0x08, 0x8E);

    idt_load((uint32_t)&idtp);
}

/* ----------------------------------------------------------------------------
 * CPU Exception Handler (called from isr_common_stub in isr.s)
 * Stack layout: gs, fs, es, ds, edi, esi, ebp, esp, ebx, edx, ecx, eax,
 *               int_no, err_code
 * ---------------------------------------------------------------------------- */
struct registers {
    uint32_t gs, fs, es, ds;
    uint32_t edi, esi, ebp, esp, ebx, edx, ecx, eax;
    uint32_t int_no, err_code;
    uint32_t eip, cs, eflags, useresp, ss;
};

void isr_handler(struct registers* regs) {
    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_RED);
    vga_gotoxy(0, 0);

    vga_puts("*** CPU EXCEPTION ***");
    vga_gotoxy(0, 1);
    vga_puts("Vector: ");
    vga_puthex(regs->int_no);
    vga_puts(" - ");

    if (regs->int_no < 32) {
        vga_puts(exception_messages[regs->int_no]);
    } else {
        vga_puts("Unknown");
    }

    vga_gotoxy(0, 2);
    vga_puts("Error code: 0x");
    vga_puthex(regs->err_code);

    vga_gotoxy(0, 3);
    vga_puts("EIP: 0x");
    vga_puthex(regs->eip);

    /* Halt the system - unrecoverable CPU exception */
    while (1) {
        asm volatile("cli; hlt");
    }
}

/* ----------------------------------------------------------------------------
 * Hardware IRQ Handler (called from irq_common_stub in isr.s)
 * ---------------------------------------------------------------------------- */
void irq_handler(struct registers* regs) {
    uint32_t irq = regs->int_no - 32;

    /* Handle spurious IRQs */
    if (irq == 7) {
        /* Check master PIC ISR - if bit 7 not set, it's spurious */
        outb(0x20, 0x0B);  /* Read ISR */
        uint8_t isr = inb(0x20);
        if (!(isr & 0x80)) {
            return;  /* Spurious IRQ7 - do NOT send EOI */
        }
    }
    if (irq == 15) {
        /* Check slave PIC ISR */
        outb(0xA0, 0x0B);
        uint8_t isr = inb(0xA0);
        if (!(isr & 0x80)) {
            /* Spurious IRQ15 - send EOI to master only */
            pic_send_eoi(15);
            return;
        }
    }

    /* Dispatch to device-specific handlers */
    switch (regs->int_no) {
        case 32: pit_handler();     break;  /* IRQ0: Timer */
        case 33: keyboard_handler(); break;  /* IRQ1: Keyboard */
        case 44: mouse_handler();   break;  /* IRQ12: Mouse */
        default: break;
    }

    pic_send_eoi(irq);
}
