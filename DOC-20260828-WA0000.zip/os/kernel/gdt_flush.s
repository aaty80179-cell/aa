[bits 32]
global gdt_flush

; void gdt_flush(uint32_t gdt_ptr_addr)
; Reloads segment registers after GDT change
gdt_flush:
    mov eax, [esp + 4]          ; Get GDT pointer address
    lgdt [eax]                  ; Load GDT

    mov ax, 0x10                ; Data segment selector (index 2, RPL=0)
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax

    jmp 0x08:.flush             ; Far jump to reload CS (code segment selector)
.flush:
    ret
