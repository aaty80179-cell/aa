#include "../include/kernel.h"

static void shell_task(void);
static void desktop_task(void);

void kernel_main(uint32_t vesa_fb_addr) {
    vga_init();
    vga_clear_screen();

    vga_set_color(VGA_COLOR_LIGHT_BLUE, VGA_COLOR_BLUE);
    vga_draw_rect(0, 0, VGA_WIDTH, VGA_HEIGHT, ' ');

    vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLUE);
    vga_gotoxy(28, 10);
    vga_puts("Windows 10 OS Clone");
    vga_gotoxy(30, 12);
    vga_puts("Version 2.0.0");
    vga_gotoxy(24, 14);
    vga_puts("Upgraded Kernel - A20/PIC/IRQ");

    vga_gotoxy(2, 16);
    vga_puts("[1/7] GDT... ");
    gdt_init();
    vga_puts("OK");

    vga_gotoxy(2, 17);
    vga_puts("[2/7] IDT... ");
    idt_init();
    vga_puts("OK");

    vga_gotoxy(2, 18);
    vga_puts("[3/7] PIC... ");
    pic_init();
    vga_puts("OK");

    vga_gotoxy(2, 19);
    vga_puts("[4/7] Paging... ");
    paging_init();
    vga_puts("OK");

    vga_gotoxy(2, 20);
    vga_puts("[5/7] PIT... ");
    pit_init();
    vga_puts("OK");

    vga_gotoxy(2, 21);
    vga_puts("[6/7] Keyboard/Mouse... ");
    keyboard_init();
    mouse_init();
    vga_puts("OK");

    vga_gotoxy(2, 22);
    vga_puts("[7/7] Tasks... ");
    task_init();
    vga_puts("OK");

    pic_clear_mask(0);
    pic_clear_mask(1);
    pic_clear_mask(12);

    asm volatile("sti");

    pit_sleep(800);

    vesa_init(vesa_fb_addr, 800, 600, 32);

    if (!vesa_is_active()) {
        vga_clear_screen();
    }

    desktop_init();
    window_init();
    taskbar_init();

    task_create(desktop_task, "desktop", 1);
    task_create(shell_task, "shell", 2);

    if (!vesa_is_active()) {
        vga_gotoxy(0, VGA_HEIGHT - 1);
        vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_DARK_GREY);
        for (int i = 0; i < VGA_WIDTH; i++) vga_putchar(' ');
        vga_gotoxy(1, VGA_HEIGHT - 1);
        vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_DARK_GREY);
        vga_puts("Win10-OS v2.0 | Tasks: ");
        vga_putdec(task_get_count());
        vga_puts(" | Mem: ");
        vga_putdec(paging_get_used() / 1024);
        vga_puts("KB");
    }

    while (1) {
        task_yield();
        asm volatile("hlt");
    }
}

static void desktop_task(void) {
    while (1) {
        task_yield();
    }
}

static void shell_task(void) {
    char cmd[64];
    int cmd_len;

    if (!vesa_is_active()) {
        vga_gotoxy(0, 15);
        vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);
        vga_puts("Win10-OS Shell v2.0");
        vga_gotoxy(0, 16);
        vga_puts("Type 'help' for commands");
    }

    while (1) {
        if (!vesa_is_active()) {
            vga_gotoxy(0, 18);
            vga_set_color(VGA_COLOR_LIGHT_GREEN, VGA_COLOR_BLACK);
            vga_puts("C:\\> ");
            vga_set_color(VGA_COLOR_WHITE, VGA_COLOR_BLACK);
        }

        cmd_len = 0;
        while (1) {
            char c = keyboard_getchar();
            if (c == '\n') break;
            if (c == '\b' && cmd_len > 0) {
                cmd_len--;
                if (!vesa_is_active()) vga_putchar('\b');
            } else if (cmd_len < 63 && c >= 32) {
                cmd[cmd_len++] = c;
                if (!vesa_is_active()) vga_putchar(c);
            }
        }
        cmd[cmd_len] = '\0';

        if (!vesa_is_active()) vga_putchar('\n');
        if (cmd_len == 0) continue;

        if (!vesa_is_active()) {
            if (cmd[0] == 'h' && cmd[1] == 'e') {
                vga_puts("Commands: help, clear, mem, tasks, reboot\n");
            } else if (cmd[0] == 'c' && cmd[1] == 'l') {
                vga_clear_screen();
                desktop_init();
                window_init();
                taskbar_init();
            } else if (cmd[0] == 'm' && cmd[1] == 'e') {
                vga_puts("Memory: ");
                vga_putdec(paging_get_used() / 1024);
                vga_puts("KB used / ");
                vga_putdec(paging_get_total() / 1024);
                vga_puts("KB total\n");
            } else if (cmd[0] == 't' && cmd[1] == 'a') {
                vga_puts("Active tasks: ");
                vga_putdec(task_get_count());
                vga_putchar('\n');
            } else if (cmd[0] == 'r' && cmd[1] == 'e') {
                vga_puts("Rebooting...\n");
                pit_sleep(500);
                outb(0x64, 0xFE);
            } else {
                vga_puts("Unknown command: ");
                vga_puts(cmd);
                vga_putchar('\n');
            }
        }
        task_yield();
    }
}
