#include "../include/kernel.h"
#include "../include/vesa.h"

/* ============================================================================
 * vesa.c - VESA VBE Linear Framebuffer Graphics Driver
 * ============================================================================
 * Supports 800x600x32bpp linear framebuffer mode.
 * Each pixel: 4 bytes = 0xAARRGGBB (little-endian: BB GG RR AA)
 * Framebuffer address passed from bootloader in EBX.
 * ============================================================================ */

static uint32_t* framebuffer = NULL;
static uint16_t screen_width = 0;
static uint16_t screen_height = 0;
static uint8_t  screen_bpp = 0;
static uint32_t screen_pitch = 0;
static uint8_t  vesa_active = 0;

/* Windows 10 color palette (0xAARRGGBB format) */
const uint32_t WIN10_BLUE      = 0xFF0078D4;
const uint32_t WIN10_DARK      = 0xFF1F1F1F;
const uint32_t WIN10_LIGHT     = 0xFFF3F3F3;
const uint32_t WIN10_WHITE     = 0xFFFFFFFF;
const uint32_t WIN10_GREY      = 0xFFCCCCCC;
const uint32_t WIN10_TASKBAR   = 0xFF1A1A1A;
const uint32_t WIN10_START     = 0xFF0078D4;
const uint32_t WIN10_ACCENT    = 0xFF00A4EF;
const uint32_t WIN10_RED       = 0xFFE81123;
const uint32_t WIN10_YELLOW    = 0xFFFFB900;
const uint32_t WIN10_GREEN     = 0xFF107C10;

/* ----------------------------------------------------------------------------
 * Initialize VESA framebuffer
 * If fb_addr is 0, VESA failed - use VGA text fallback
 * ---------------------------------------------------------------------------- */
void vesa_init(uint32_t fb_addr, uint16_t width, uint16_t height, uint8_t bpp) {
    if (fb_addr == 0) {
        vesa_active = 0;
        return;
    }

    framebuffer = (uint32_t*)fb_addr;
    screen_width = width ? width : 800;
    screen_height = height ? height : 600;
    screen_bpp = bpp ? bpp : 32;
    screen_pitch = screen_width * (screen_bpp / 8);
    vesa_active = 1;
}

/* ----------------------------------------------------------------------------
 * Check if VESA graphics mode is active
 * ---------------------------------------------------------------------------- */
uint8_t vesa_is_active(void) {
    return vesa_active;
}

/* ----------------------------------------------------------------------------
 * Put single pixel
 * ---------------------------------------------------------------------------- */
void vesa_put_pixel(int x, int y, uint32_t color) {
    if (!vesa_active) return;
    if (x < 0 || x >= screen_width || y < 0 || y >= screen_height) return;
    framebuffer[y * screen_width + x] = color;
}

/* ----------------------------------------------------------------------------
 * Fill rectangle
 * ---------------------------------------------------------------------------- */
void vesa_fill_rect(int x, int y, int w, int h, uint32_t color) {
    if (!vesa_active) return;

    int x1 = (x < 0) ? 0 : x;
    int y1 = (y < 0) ? 0 : y;
    int x2 = (x + w > screen_width) ? screen_width : x + w;
    int y2 = (y + h > screen_height) ? screen_height : y + h;

    for (int row = y1; row < y2; row++) {
        for (int col = x1; col < x2; col++) {
            framebuffer[row * screen_width + col] = color;
        }
    }
}

/* ----------------------------------------------------------------------------
 * Clear screen with color
 * ---------------------------------------------------------------------------- */
void vesa_clear_screen(uint32_t color) {
    vesa_fill_rect(0, 0, screen_width, screen_height, color);
}

/* ----------------------------------------------------------------------------
 * Draw horizontal line
 * ---------------------------------------------------------------------------- */
void vesa_hline(int x, int y, int w, uint32_t color) {
    vesa_fill_rect(x, y, w, 1, color);
}

/* ----------------------------------------------------------------------------
 * Draw vertical line
 * ---------------------------------------------------------------------------- */
void vesa_vline(int x, int y, int h, uint32_t color) {
    vesa_fill_rect(x, y, 1, h, color);
}

/* ----------------------------------------------------------------------------
 * Draw rectangle outline
 * ---------------------------------------------------------------------------- */
void vesa_draw_rect(int x, int y, int w, int h, uint32_t color) {
    vesa_hline(x, y, w, color);
    vesa_hline(x, y + h - 1, w, color);
    vesa_vline(x, y, h, color);
    vesa_vline(x + w - 1, y, h, color);
}

/* ----------------------------------------------------------------------------
 * Draw desktop background with icons
 * ---------------------------------------------------------------------------- */
void vesa_draw_desktop(void) {
    if (!vesa_active) return;

    /* Blue gradient background */
    vesa_clear_screen(WIN10_BLUE);

    /* Desktop icons (simple squares with labels) */
    int icon_x = 20;
    int icon_y = 20;
    int icon_size = 48;
    int spacing = 80;

    /* My Computer */
    vesa_fill_rect(icon_x, icon_y, icon_size, icon_size, WIN10_LIGHT);
    vesa_draw_rect(icon_x, icon_y, icon_size, icon_size, WIN10_WHITE);

    /* Recycle Bin */
    vesa_fill_rect(icon_x, icon_y + spacing, icon_size, icon_size, WIN10_LIGHT);
    vesa_draw_rect(icon_x, icon_y + spacing, icon_size, icon_size, WIN10_WHITE);

    /* Documents */
    vesa_fill_rect(icon_x, icon_y + spacing * 2, icon_size, icon_size, WIN10_LIGHT);
    vesa_draw_rect(icon_x, icon_y + spacing * 2, icon_size, icon_size, WIN10_WHITE);

    /* Settings */
    vesa_fill_rect(icon_x, icon_y + spacing * 3, icon_size, icon_size, WIN10_LIGHT);
    vesa_draw_rect(icon_x, icon_y + spacing * 3, icon_size, icon_size, WIN10_WHITE);
}

/* ----------------------------------------------------------------------------
 * Draw taskbar
 * ---------------------------------------------------------------------------- */
void vesa_draw_taskbar(void) {
    if (!vesa_active) return;

    int tb_height = 40;
    int tb_y = screen_height - tb_height;

    /* Taskbar background */
    vesa_fill_rect(0, tb_y, screen_width, tb_height, WIN10_TASKBAR);

    /* Start button */
    vesa_fill_rect(10, tb_y + 5, 48, 30, WIN10_START);

    /* Taskbar items */
    vesa_fill_rect(70, tb_y + 5, 120, 30, 0xFF333333);
    vesa_fill_rect(200, tb_y + 5, 100, 30, 0xFF333333);
    vesa_fill_rect(310, tb_y + 5, 100, 30, 0xFF333333);

    /* System tray area */
    vesa_fill_rect(screen_width - 120, tb_y + 5, 110, 30, 0xFF333333);
}

/* ----------------------------------------------------------------------------
 * Draw window with title bar and buttons
 * ---------------------------------------------------------------------------- */
void vesa_draw_window(int x, int y, int w, int h, const char* title) {
    if (!vesa_active) return;

    /* Shadow */
    vesa_fill_rect(x + 4, y + 4, w, h, 0x80000000);

    /* Title bar */
    vesa_fill_rect(x, y, w, 30, WIN10_BLUE);

    /* Window body */
    vesa_fill_rect(x, y + 30, w, h - 30, WIN10_WHITE);

    /* Border */
    vesa_draw_rect(x, y, w, h, 0xFF808080);

    /* Window buttons */
    int btn_y = y + 5;
    int btn_size = 20;

    /* Close button (red) */
    vesa_fill_rect(x + w - 25, btn_y, btn_size, btn_size, WIN10_RED);
    /* Maximize button (green) */
    vesa_fill_rect(x + w - 50, btn_y, btn_size, btn_size, WIN10_GREEN);
    /* Minimize button (yellow) */
    vesa_fill_rect(x + w - 75, btn_y, btn_size, btn_size, WIN10_YELLOW);
}
