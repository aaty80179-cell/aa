#include "../include/kernel.h"
#include "../include/pit.h"

/* ============================================================================
 * pit.c - Programmable Interval Timer (8253/8254)
 * ============================================================================
 * Channel 0: System timer (IRQ0)
 * Frequency: 1193182 Hz base / divisor = desired Hz
 * We use 100 Hz = 10ms ticks
 * ============================================================================ */

#define PIT_CHANNEL0    0x40
#define PIT_COMMAND     0x43
#define PIT_FREQUENCY   1193182
#define TIMER_HZ        100

volatile uint32_t pit_ticks = 0;

/* ----------------------------------------------------------------------------
 * Initialize PIT to fire at TIMER_HZ (100 Hz)
 * ---------------------------------------------------------------------------- */
void pit_init(void) {
    uint32_t divisor = PIT_FREQUENCY / TIMER_HZ;

    /* Command: Channel 0, Access mode lobyte/hibyte, Mode 3 (square wave), Binary */
    outb(PIT_COMMAND, 0x36);

    /* Set divisor (low byte then high byte) */
    outb(PIT_CHANNEL0, divisor & 0xFF);
    outb(PIT_CHANNEL0, (divisor >> 8) & 0xFF);
}

/* ----------------------------------------------------------------------------
 * Timer interrupt handler (called from irq_handler)
 * ---------------------------------------------------------------------------- */
void pit_handler(void) {
    pit_ticks++;
}

/* ----------------------------------------------------------------------------
 * Get current tick count
 * ---------------------------------------------------------------------------- */
uint32_t pit_get_ticks(void) {
    return pit_ticks;
}

/* ----------------------------------------------------------------------------
 * Sleep for milliseconds (coarse, uses busy-wait with hlt)
 * ---------------------------------------------------------------------------- */
void pit_sleep(uint32_t ms) {
    uint32_t target = pit_ticks + (ms * TIMER_HZ / 1000);
    while (pit_ticks < target) {
        asm volatile("sti; hlt; cli");
    }
}
