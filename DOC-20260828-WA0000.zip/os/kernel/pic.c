#include "../include/kernel.h"
#include "../include/pic.h"

/* ============================================================================
 * pic.c - 8259 Programmable Interrupt Controller
 * ============================================================================
 * The IBM PC uses two cascaded 8259 PIC chips:
 *   - Master PIC at ports 0x20 (command) / 0x21 (data)
 *   - Slave PIC at ports 0xA0 (command) / 0xA1 (data)
 *
 * In protected mode, IRQs 0-7 conflict with CPU exceptions 8-15.
 * We remap them: IRQ 0-7 -> ISR 32-39, IRQ 8-15 -> ISR 40-47.
 * ============================================================================ */

#define PIC1_COMMAND    0x20
#define PIC1_DATA       0x21
#define PIC2_COMMAND    0xA0
#define PIC2_DATA       0xA1

#define ICW1_INIT       0x10    /* Initialization bit */
#define ICW1_ICW4       0x01    /* ICW4 needed */
#define ICW4_8086       0x01    /* 8086/88 mode */

/* ----------------------------------------------------------------------------
 * Initialize both PICs with proper remapping
 * ---------------------------------------------------------------------------- */
void pic_init(void) {
    uint8_t a1, a2;

    /* Save masks */
    a1 = inb(PIC1_DATA);
    a2 = inb(PIC2_DATA);

    /* Start initialization sequence (cascade mode) */
    outb(PIC1_COMMAND, ICW1_INIT | ICW1_ICW4);
    io_wait();
    outb(PIC2_COMMAND, ICW1_INIT | ICW1_ICW4);
    io_wait();

    /* ICW2: Vector offsets */
    outb(PIC1_DATA, 0x20);      /* Master: IRQ 0-7 -> ISR 32-39 */
    io_wait();
    outb(PIC2_DATA, 0x28);      /* Slave: IRQ 8-15 -> ISR 40-47 */
    io_wait();

    /* ICW3: Tell master about slave at IRQ2 */
    outb(PIC1_DATA, 0x04);      /* Slave at IRQ2 (bit 2) */
    io_wait();
    outb(PIC2_DATA, 0x02);      /* Slave identity (cascade identity = 2) */
    io_wait();

    /* ICW4: 8086 mode */
    outb(PIC1_DATA, ICW4_8086);
    io_wait();
    outb(PIC2_DATA, ICW4_8086);
    io_wait();

    /* Restore masks (all IRQs masked initially) */
    outb(PIC1_DATA, 0xFF);
    outb(PIC2_DATA, 0xFF);
}

/* ----------------------------------------------------------------------------
 * Send End-of-Interrupt (EOI) to PIC(s)
 * ---------------------------------------------------------------------------- */
void pic_send_eoi(uint8_t irq) {
    if (irq >= 8) {
        outb(PIC2_COMMAND, 0x20);   /* EOI to slave */
    }
    outb(PIC1_COMMAND, 0x20);       /* EOI to master */
}

/* ----------------------------------------------------------------------------
 * Set IRQ mask (disable IRQ)
 * ---------------------------------------------------------------------------- */
void pic_set_mask(uint8_t irq) {
    uint16_t port = (irq < 8) ? PIC1_DATA : PIC2_DATA;
    if (irq >= 8) irq -= 8;
    outb(port, inb(port) | (1 << irq));
}

/* ----------------------------------------------------------------------------
 * Clear IRQ mask (enable IRQ)
 * ---------------------------------------------------------------------------- */
void pic_clear_mask(uint8_t irq) {
    uint16_t port = (irq < 8) ? PIC1_DATA : PIC2_DATA;
    if (irq >= 8) irq -= 8;
    outb(port, inb(port) & ~(1 << irq));
}
