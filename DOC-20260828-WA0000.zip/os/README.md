# Windows 10 OS Clone - Real Operating System v2.0

A real bare-metal operating system for x86 (i686) architecture, built from scratch.

## Features

- **Real Mode Bootloader** with A20 + VESA VBE 800x600x32bpp
- **32-bit Protected Mode Kernel** with flat 4GB segments
- **GDT/IDT** with 256 interrupt entries
- **PIC Remapping** (IRQ 0-15 -> ISR 32-47)
- **Memory Paging** with identity mapping + kmalloc
- **PIT Timer** at 100Hz
- **PS/2 Keyboard & Mouse** drivers
- **VGA Text Mode** + **VESA Linear Framebuffer**
- **Cooperative Multitasking** (Linux-style TSS-less)
- **Windows 10-like GUI** (desktop, taskbar, windows)
- **Interactive Shell** with commands

## Project Structure

```
os/
├── boot/boot.s              # Stage 1 bootloader (512 bytes)
├── kernel/
│   ├── kernel.c             # Main entry point
│   ├── gdt.c                # Global Descriptor Table
│   ├── idt.c                # Interrupt Descriptor Table
│   ├── pic.c                # PIC 8259 remapping
│   ├── vga.c                # VGA text mode driver
│   ├── vesa.c               # VESA VBE framebuffer
│   ├── paging.c             # Memory paging + heap
│   ├── pit.c                # Programmable Interval Timer
│   ├── multitasking.c       # Task scheduler
│   ├── gdt_flush.s          # GDT reload (ASM)
│   ├── isr.s                # 48 ISR/IRQ stubs (ASM)
│   ├── task_switch.s        # Context switch (ASM)
│   └── gui/
│       ├── desktop.c        # Desktop rendering
│       ├── taskbar.c        # Taskbar rendering
│       └── window.c         # Window rendering
├── drivers/
│   ├── keyboard.c           # PS/2 keyboard driver
│   └── mouse.c              # PS/2 mouse driver
├── include/
│   ├── kernel.h               # Core definitions
│   ├── vga.h                  # VGA API
│   ├── vesa.h                 # VESA API
│   ├── paging.h               # Memory manager API
│   ├── pit.h                  # Timer API
│   ├── mouse.h                # Mouse API
│   ├── multitasking.h         # Task scheduler API
│   ├── pic.h                  # PIC API
│   └── gui.h                  # GUI API
├── linker.ld                # Linker script
└── Makefile                 # Build automation
```

## Building

### Prerequisites
```bash
sudo apt-get install nasm qemu-system-x86 build-essential
```

### Cross Compiler (i686-elf-gcc)
```bash
# Option 1: Docker
docker run -it -v "$PWD:/src" lordmilko/i686-elf-tools

# Option 2: Build from source (see OSDev Wiki)
```

### Compile & Run
```bash
cd os
make
make run
```

## Architecture

- **Boot**: BIOS -> Real Mode -> Protected Mode -> Kernel @ 0x1000
- **Memory**: Identity map first 4MB, heap at 4MB-8MB
- **Interrupts**: IDT[256], PIC remapped, IRQ 0=Timer, 1=Keyboard, 12=Mouse
- **Tasks**: Cooperative round-robin, 16 max, 8KB stack each

## License

Educational project. Free to use and modify.
