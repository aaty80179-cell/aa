#include "../include/kernel.h"

#define MOUSE_DATA_PORT     0x60
#define MOUSE_STATUS_PORT   0x64
#define MOUSE_COMMAND_PORT  0x64

static int8_t mouse_x = 40;
static int8_t mouse_y = 12;
static uint8_t mouse_buttons = 0;
static uint8_t mouse_cycle = 0;
static int8_t mouse_packet[3];

static void mouse_wait(uint8_t type) {
    if (type == 0) {
        while (!(inb(MOUSE_STATUS_PORT) & 1));
    } else {
        while (inb(MOUSE_STATUS_PORT) & 2);
    }
}

static void mouse_write(uint8_t data) {
    mouse_wait(1);
    outb(MOUSE_COMMAND_PORT, 0xD4);
    mouse_wait(1);
    outb(MOUSE_DATA_PORT, data);
}

static uint8_t mouse_read(void) {
    mouse_wait(0);
    return inb(MOUSE_DATA_PORT);
}

void mouse_init(void) {
    uint8_t status;

    mouse_wait(1);
    outb(MOUSE_COMMAND_PORT, 0xA8);

    mouse_wait(1);
    outb(MOUSE_COMMAND_PORT, 0x20);
    mouse_wait(0);
    status = (inb(MOUSE_DATA_PORT) | 2);
    mouse_wait(1);
    outb(MOUSE_COMMAND_PORT, 0x60);
    mouse_wait(1);
    outb(MOUSE_DATA_PORT, status);

    mouse_write(0xF6);
    mouse_read();

    mouse_write(0xF4);
    mouse_read();
}

void mouse_handler(void) {
    uint8_t status = inb(MOUSE_STATUS_PORT);
    if (!(status & 0x20)) return;

    mouse_packet[mouse_cycle] = inb(MOUSE_DATA_PORT);

    if (mouse_cycle == 0) {
        if (!(mouse_packet[0] & 0x08)) return;
    }

    mouse_cycle++;

    if (mouse_cycle == 3) {
        mouse_cycle = 0;
        mouse_buttons = mouse_packet[0] & 0x07;
        mouse_x += mouse_packet[1];
        mouse_y -= mouse_packet[2];

        if (mouse_x < 0) mouse_x = 0;
        if (mouse_y < 0) mouse_y = 0;
        if (mouse_x > 79) mouse_x = 79;
        if (mouse_y > 24) mouse_y = 24;
    }
}

int8_t mouse_get_x(void) { return mouse_x; }
int8_t mouse_get_y(void) { return mouse_y; }
uint8_t mouse_get_buttons(void) { return mouse_buttons; }
