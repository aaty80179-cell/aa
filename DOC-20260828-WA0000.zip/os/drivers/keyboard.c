#include "../include/kernel.h"

#define KEYBOARD_DATA_PORT    0x60

static const char scancode_set1[] = {
    0,  0,  '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
    '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',
    0,  'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`', 0,
    '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0,  '*', 0,  ' '
};

static const char scancode_set1_shift[] = {
    0,  0,  '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '\b',
    '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', '\n',
    0,  'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"', '~', 0,
    '|', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', 0,  '*', 0,  ' '
};

#define KB_BUF_SIZE 256
static volatile char kb_buffer[KB_BUF_SIZE];
static volatile uint8_t kb_head = 0;
static volatile uint8_t kb_tail = 0;
static volatile uint8_t shift_pressed = 0;
static volatile uint8_t caps_lock = 0;

void keyboard_handler(void) {
    uint8_t scancode = inb(KEYBOARD_DATA_PORT);

    if (scancode == 0x2A || scancode == 0x36) {
        shift_pressed = 1;
        return;
    }
    if (scancode == 0xAA || scancode == 0xB6) {
        shift_pressed = 0;
        return;
    }
    if (scancode == 0x3A) {
        caps_lock = !caps_lock;
        return;
    }

    if (scancode < 128) {
        char c;
        if (shift_pressed ^ caps_lock) {
            c = scancode_set1_shift[scancode];
        } else {
            c = scancode_set1[scancode];
        }

        if (c) {
            uint8_t next = (kb_head + 1) % KB_BUF_SIZE;
            if (next != kb_tail) {
                kb_buffer[kb_head] = c;
                kb_head = next;
            }
        }
    }
}

char keyboard_getchar(void) {
    while (kb_head == kb_tail) {
        asm volatile("sti; hlt; cli");
    }
    char c = kb_buffer[kb_tail];
    kb_tail = (kb_tail + 1) % KB_BUF_SIZE;
    return c;
}

uint8_t keyboard_has_char(void) {
    return kb_head != kb_tail;
}

void keyboard_init(void) {
    kb_head = 0;
    kb_tail = 0;
    shift_pressed = 0;
    caps_lock = 0;
}
