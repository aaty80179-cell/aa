; ============================================================================
; boot.s - Stage 1 Bootloader for Win10-OS Clone v2.0
; ============================================================================
; Architecture: x86 (i686), Real Mode -> Protected Mode (32-bit)
; Features:
;   - A20 Line Enablement (Fast A20, BIOS, Keyboard Controller)
;   - VESA VBE 2.0+ Linear Framebuffer Mode (800x600x32bpp)
;   - Load 48 sectors (~24KB) kernel from disk
;   - Pass VESA framebuffer address to kernel in EBX
;   - Flat 4GB GDT (code + data segments)
; ============================================================================
[bits 16]
[org 0x7C00]

; ----------------------------------------------------------------------------
; Constants
; ----------------------------------------------------------------------------
KERNEL_OFFSET       equ 0x1000          ; Kernel load address
KERNEL_SECTORS      equ 48              ; Sectors to load (24KB)
VESA_INFO_SEG       equ 0x7000          ; VESA info block segment
VESA_INFO_OFF       equ 0x0000          ; VESA info block offset
VESA_MODE_SEG       equ 0x7000          ; VESA mode info segment
VESA_MODE_OFF       equ 0x0200          ; VESA mode info offset
VESA_MODE_NUM       equ 0x118           ; 800x600x32bpp linear (0x118 = 0x118 | 0x4000)

; ----------------------------------------------------------------------------
; Entry Point
; ----------------------------------------------------------------------------
start:
    ; Zero segment registers
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x9000                      ; Stack at 0x90000

    ; Save boot drive
    mov [BOOT_DRIVE], dl

    ; Print boot message
    mov si, MSG_BOOT
    call print_string

    ; ------------------------------------------------------------------------
    ; Step 1: Enable A20 Line (critical for memory above 1MB)
    ; ------------------------------------------------------------------------
    call enable_a20
    jc .a20_fail
    mov si, MSG_A20_OK
    call print_string
    jmp .a20_done
.a20_fail:
    mov si, MSG_A20_FAIL
    call print_string
    ; Continue anyway - some systems work without A20
.a20_done:

    ; ------------------------------------------------------------------------
    ; Step 2: Set VESA VBE Linear Framebuffer Mode
    ; ------------------------------------------------------------------------
    call set_vesa_mode
    jc .vesa_fail
    mov si, MSG_VESA_OK
    call print_string
    jmp .vesa_done
.vesa_fail:
    mov si, MSG_VESA_FAIL
    call print_string
    ; Continue in VGA text mode fallback
.vesa_done:

    ; ------------------------------------------------------------------------
    ; Step 3: Load kernel from disk
    ; ------------------------------------------------------------------------
    call load_kernel

    ; ------------------------------------------------------------------------
    ; Step 4: Switch to 32-bit Protected Mode
    ; ------------------------------------------------------------------------
    call switch_to_32bit

    ; Should never reach here
    jmp $

; ============================================================================
; A20 Line Enablement
; ============================================================================
enable_a20:
    ; Try Fast A20 first (System Control Port A, bit 1)
    in al, 0x92
    test al, 2
    jnz .a20_enabled                    ; Already enabled
    or al, 2
    and al, 0xFE                        ; Clear reset bit
    out 0x92, al

.a20_enabled:
    call check_a20
    jnc .done                           ; Success

    ; Try BIOS method (INT 0x15, AX=0x2401)
    mov ax, 0x2401
    int 0x15
    call check_a20
    jnc .done

    ; Try Keyboard Controller method
    call .kbd_enable_a20
    call check_a20
    jnc .done

    ; All methods failed
    stc
    ret

.kbd_enable_a20:
    cli
    call .kbd_wait_cmd
    mov al, 0xAD                        ; Disable keyboard
    out 0x64, al
    call .kbd_wait_cmd
    mov al, 0xD0                        ; Read output port
    out 0x64, al
    call .kbd_wait_data
    in al, 0x60
    push ax
    call .kbd_wait_cmd
    mov al, 0xD1                        ; Write output port
    out 0x64, al
    call .kbd_wait_cmd
    pop ax
    or al, 2                            ; Set A20 bit
    out 0x60, al
    call .kbd_wait_cmd
    mov al, 0xAE                        ; Enable keyboard
    out 0x64, al
    call .kbd_wait_cmd
    sti
    ret

.kbd_wait_cmd:
    in al, 0x64
    test al, 2
    jnz .kbd_wait_cmd
    ret

.kbd_wait_data:
    in al, 0x64
    test al, 1
    jz .kbd_wait_data
    ret

check_a20:
    pushf
    push ds
    push es
    push di
    push si

    xor ax, ax
    mov es, ax
    not ax
    mov ds, ax
    mov di, 0x0500
    mov si, 0x0510

    ; Save original values
    mov al, [es:di]
    push ax
    mov al, [ds:si]
    push ax

    ; Test: write different values
    mov byte [es:di], 0x00
    mov byte [ds:si], 0xFF
    cmp byte [es:di], 0xFF

    ; Restore original values
    pop ax
    mov [ds:si], al
    pop ax
    mov [es:di], al

    ; If equal, A20 is disabled (wrap-around occurred)
    je .a20_disabled
    clc
    jmp .a20_check_done
.a20_disabled:
    stc
.a20_check_done:
    pop si
    pop di
    pop es
    pop ds
    popf
    ret

done:
    ret

; ============================================================================
; VESA VBE Mode Setting
; ============================================================================
set_vesa_mode:
    push es

    ; Get VESA info
    mov ax, VESA_INFO_SEG
    mov es, ax
    mov di, VESA_INFO_OFF
    mov dword [es:di], 'VBE2'           ; Signature for VBE 2.0+
    mov ax, 0x4F00
    int 0x10
    cmp ax, 0x004F
    jne .vesa_fail

    ; Get mode info for 800x600x32bpp
    mov ax, VESA_MODE_SEG
    mov es, ax
    mov di, VESA_MODE_OFF
    mov cx, VESA_MODE_NUM
    mov ax, 0x4F01
    int 0x10
    cmp ax, 0x004F
    jne .vesa_fail

    ; Check if linear framebuffer is supported (bit 7 of mode attributes)
    mov ax, VESA_MODE_SEG
    mov es, ax
    mov di, VESA_MODE_OFF
    test word [es:di], 0x0080
    jz .vesa_fail

    ; Set mode with linear framebuffer (OR with 0x4000)
    mov bx, VESA_MODE_NUM
    or bx, 0x4000                       ; Linear framebuffer bit
    mov ax, 0x4F02
    int 0x10
    cmp ax, 0x004F
    jne .vesa_fail

    pop es
    clc
    ret

.vesa_fail:
    pop es
    stc
    ret

; ============================================================================
; Load Kernel from Disk (INT 0x13)
; ============================================================================
load_kernel:
    mov si, MSG_LOAD
    call print_string

    mov ah, 0x02                        ; Read sectors
    mov al, KERNEL_SECTORS
    mov ch, 0                           ; Cylinder 0
    mov cl, 2                           ; Start at sector 2
    mov dh, 0                           ; Head 0
    mov dl, [BOOT_DRIVE]
    mov bx, KERNEL_OFFSET
    int 0x13
    jc .disk_error

    mov si, MSG_OK
    call print_string
    ret

.disk_error:
    mov si, MSG_ERROR
    call print_string
    jmp $

; ============================================================================
; Switch to 32-bit Protected Mode
; ============================================================================
switch_to_32bit:
    cli                                 ; Disable interrupts
    lgdt [gdt_descriptor]               ; Load GDT

    ; Enable protected mode (PE bit in CR0)
    mov eax, cr0
    or eax, 1
    mov cr0, eax

    ; Far jump to flush pipeline and load CS
    jmp CODE_SEG:.pmode

[bits 32]
.pmode:
    ; Setup data segments
    mov ax, DATA_SEG
    mov ds, ax
    mov ss, ax
    mov es, ax
    mov fs, ax
    mov gs, ax

    ; Setup stack
    mov ebp, 0x90000
    mov esp, ebp

    ; Pass VESA framebuffer address to kernel in EBX
    ; Framebuffer address is at VESA_MODE_OFF + 0x28 (PhysBasePtr)
    mov eax, VESA_MODE_SEG
    shl eax, 4
    add eax, VESA_MODE_OFF
    add eax, 0x28                       ; Offset to PhysBasePtr
    mov ebx, [eax]

    ; If VESA failed, EBX will be 0, kernel should detect and use VGA text
    call KERNEL_OFFSET
    jmp $

[bits 16]
; ============================================================================
; GDT - Flat 4GB segments (null, code, data)
; ============================================================================
gdt_start:
    dq 0x0000000000000000               ; Null descriptor
gdt_code:
    dw 0xFFFF                           ; Limit low
    dw 0x0000                           ; Base low
    db 0x00                             ; Base middle
    db 10011010b                        ; Access: present, ring 0, code, readable
    db 11001111b                        ; Flags: 4KB granularity, 32-bit, limit high
    db 0x00                             ; Base high
gdt_data:
    dw 0xFFFF                           ; Limit low
    dw 0x0000                           ; Base low
    db 0x00                             ; Base middle
    db 10010010b                        ; Access: present, ring 0, data, writable
    db 11001111b                        ; Flags: 4KB granularity, 32-bit, limit high
    db 0x00                             ; Base high
gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start - 1          ; Limit
    dd gdt_start                        ; Base

CODE_SEG equ gdt_code - gdt_start
DATA_SEG equ gdt_data - gdt_start

; ============================================================================
; Utilities
; ============================================================================
print_string:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    int 0x10
    jmp print_string
.done:
    ret

; ============================================================================
; Data
; ============================================================================
BOOT_DRIVE      db 0
MSG_BOOT        db "Win10-OS v2.0 Booting...", 13, 10, 0
MSG_A20_OK      db "[OK] A20 enabled", 13, 10, 0
MSG_A20_FAIL    db "[WARN] A20 failed", 13, 10, 0
MSG_VESA_OK     db "[OK] VESA 800x600x32", 13, 10, 0
MSG_VESA_FAIL   db "[WARN] VESA failed, using VGA text", 13, 10, 0
MSG_LOAD        db "Loading kernel...", 0
MSG_OK          db " OK", 13, 10, 0
MSG_ERROR       db " FAIL", 13, 10, 0

; ============================================================================
; Boot Signature
; ============================================================================
times 510-($-$$) db 0
dw 0xAA55
