#ifndef VESA_H
#define VESA_H

#include <stdint.h>

extern const uint32_t WIN10_BLUE;
extern const uint32_t WIN10_DARK;
extern const uint32_t WIN10_LIGHT;
extern const uint32_t WIN10_WHITE;
extern const uint32_t WIN10_GREY;
extern const uint32_t WIN10_TASKBAR;
extern const uint32_t WIN10_START;
extern const uint32_t WIN10_ACCENT;
extern const uint32_t WIN10_RED;
extern const uint32_t WIN10_YELLOW;
extern const uint32_t WIN10_GREEN;

void vesa_init(uint32_t fb_addr, uint16_t width, uint16_t height, uint8_t bpp);
uint8_t vesa_is_active(void);
void vesa_put_pixel(int x, int y, uint32_t color);
void vesa_fill_rect(int x, int y, int w, int h, uint32_t color);
void vesa_clear_screen(uint32_t color);
void vesa_hline(int x, int y, int w, uint32_t color);
void vesa_vline(int x, int y, int h, uint32_t color);
void vesa_draw_rect(int x, int y, int w, int h, uint32_t color);
void vesa_draw_desktop(void);
void vesa_draw_taskbar(void);
void vesa_draw_window(int x, int y, int w, int h, const char* title);

#endif
