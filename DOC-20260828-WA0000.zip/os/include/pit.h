#ifndef PIT_H
#define PIT_H

#include <stdint.h>

void pit_init(void);
void pit_handler(void);
uint32_t pit_get_ticks(void);
void pit_sleep(uint32_t ms);

extern volatile uint32_t pit_ticks;

#endif
