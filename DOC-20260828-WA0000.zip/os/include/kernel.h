#ifndef KERNEL_H
#define KERNEL_H

#include <stdint.h>
#include <stddef.h>

static inline void outb(uint16_t port, uint8_t val) {
    asm volatile("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t ret;
    asm volatile("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline void outw(uint16_t port, uint16_t val) {
    asm volatile("outw %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint16_t inw(uint16_t port) {
    uint16_t ret;
    asm volatile("inw %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline void io_wait(void) {
    asm volatile("outb %%al, $0x80" : : "a"(0));
}

#include "vga.h"
#include "vesa.h"
#include "paging.h"
#include "pit.h"
#include "mouse.h"
#include "multitasking.h"
#include "pic.h"
#include "gui.h"

void gdt_init(void);
void idt_init(void);
void pic_init(void);
void paging_init(void);
void pit_init(void);
void task_init(void);

void keyboard_init(void);
void mouse_init(void);

void keyboard_handler(void);
void mouse_handler(void);
void pit_handler(void);

struct registers {
    uint32_t gs, fs, es, ds;
    uint32_t edi, esi, ebp, esp, ebx, edx, ecx, eax;
    uint32_t int_no, err_code;
    uint32_t eip, cs, eflags, useresp, ss;
};

void isr_handler(struct registers* regs);
void irq_handler(struct registers* regs);

#endif
