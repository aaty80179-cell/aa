#ifndef PAGING_H
#define PAGING_H

#include <stdint.h>

void paging_init(void);
void* kmalloc(uint32_t size);
void kfree(void* ptr);
uint32_t paging_get_used(void);
uint32_t paging_get_total(void);

#endif
