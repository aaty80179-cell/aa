#ifndef MULTITASKING_H
#define MULTITASKING_H

#include <stdint.h>

void task_init(void);
int task_create(void (*entry_point)(void), const char* name, uint8_t priority);
void task_yield(void);
void task_exit(void);
int task_get_current(void);
const char* task_get_name(int pid);
int task_get_count(void);

#endif
