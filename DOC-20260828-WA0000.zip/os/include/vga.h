#ifndef VGA_H
#define VGA_H

#define VGA_WIDTH   80
#define VGA_HEIGHT  25

enum vga_color {
    VGA_COLOR_BLACK = 0,
    VGA_COLOR_BLUE = 1,
    VGA_COLOR_GREEN = 2,
    VGA_COLOR_CYAN = 3,
    VGA_COLOR_RED = 4,
    VGA_COLOR_MAGENTA = 5,
    VGA_COLOR_BROWN = 6,
    VGA_COLOR_LIGHT_GREY = 7,
    VGA_COLOR_DARK_GREY = 8,
    VGA_COLOR_LIGHT_BLUE = 9,
    VGA_COLOR_LIGHT_GREEN = 10,
    VGA_COLOR_LIGHT_CYAN = 11,
    VGA_COLOR_LIGHT_RED = 12,
    VGA_COLOR_LIGHT_MAGENTA = 13,
    VGA_COLOR_YELLOW = 14,
    VGA_COLOR_WHITE = 15,
};

void vga_init(void);
void vga_clear_screen(void);
void vga_gotoxy(uint16_t x, uint16_t y);
void vga_set_color(enum vga_color fg, enum vga_color bg);
void vga_putchar(char c);
void vga_puts(const char* str);
void vga_puthex(uint32_t num);
void vga_putdec(uint32_t num);
void vga_draw_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, char c);

uint8_t vga_entry_color(enum vga_color fg, enum vga_color bg);

#endif
