#ifndef MOUSE_H
#define MOUSE_H

#include <stdint.h>

void mouse_init(void);
void mouse_handler(void);
int8_t mouse_get_x(void);
int8_t mouse_get_y(void);
uint8_t mouse_get_buttons(void);

#endif
