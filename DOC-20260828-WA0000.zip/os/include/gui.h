#ifndef GUI_H
#define GUI_H

#include "vga.h"
#include "vesa.h"

void desktop_init(void);
void taskbar_init(void);
void window_init(void);

#endif
